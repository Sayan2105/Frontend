
export const hospital_name = 'Vertical Healthcare'

export const hospital_slogan = 'Your Health is our priority'

export const address = {
    street: 'New Market purwa',
    city: 'Tulsipur, UP, 271208 ',
}

export const hospital_contact = {
    phone: '+91 9876543210',
    email: 'info@example.com',
}

export const hospital_website = 'https://example.com'

export const page_limit = 10