import { Outlet } from "react-router-dom"

const AdminLayout = () => {
  return (
   <Outlet></Outlet>
  )
}

export default AdminLayout