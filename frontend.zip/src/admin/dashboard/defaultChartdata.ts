export const Default_MM_Inc_Exp_Data = [
    { month: "January", Income: 0, Expenses: 0 },
    { month: "February", Income: 0, Expenses: 0 },
    { month: "March", Income: 0, Expenses: 0 },
    { month: "April", Income: 0, Expenses: 0 },
    { month: "May", Income: 0, Expenses: 0 },
    { month: "June", Income: 0, Expenses: 0 },
    { month: "July", Income: 0, Expenses: 0 },
    { month: "August", Income: 0, Expenses: 0 },
    { month: "September", Income: 0, Expenses: 0 },
    { month: "October", Income: 0, Expenses: 0 },
    { month: "November", Income: 0, Expenses: 0 },
    { month: "December", Income: 0, Expenses: 0 }
];