
export interface VitalType {
  id: number,
  value: string,
  date: string,
  setup_VitalId: number,
  vital: {
    name: string
  }
}

