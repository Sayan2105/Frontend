export interface timeline {
    id: 1,
    date: string,
    title: string,
    description: string,
}