export type SetupVital = {
    id: number,
    name: string,
    from: string,
    to: string,
    unit: string,
}