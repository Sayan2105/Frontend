export type Events = {
    id: number,
    title: string,
    start: string,
    end: string,
    allDay: boolean
}