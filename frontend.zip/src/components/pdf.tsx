import { address, hospital_contact, hospital_name, hospital_website } from "@/globalData"
import { currencyFormat } from "@/lib/utils"
import { Printer } from "lucide-react"
import React, { ButtonHTMLAttributes } from "react"

interface headerProps {
    id: string | number
    title: string,
    date: string,
}

export const PdfHeader = ({ id, title, date }: headerProps) => {
    return (
        <div className="flex flex-row justify-between gap-5 mb-4 items-center border-b-2 border-gray-200 border-dashed p-5">
            <div >
                <div className="flex items-center gap-2">
                    <img src="/logo.png" alt="Logo" className="w-16 h-16 object-cover" />
                    <div>
                        <h1 className="text-xl font-bold text-gray-800">{hospital_name}</h1>
                        <p className="text-xs text-gray-600">{hospital_website}</p>
                    </div>
                </div>
            </div>
            <div className="text-end">
                <h1 className="text-xl font-bold text-gray-800">{title}</h1>
                <p className="text-xs text-gray-600 font-mono">#{id}</p>
                <p className="text-xs text-gray-600">Date: {date}</p>
            </div>
        </div>
    )
}



export const From = () => {
    return (
        <div className="bg-gray-50 p-6 rounded-lg">
            <h3 className="text-sm font-semibold text-gray-600 uppercase mb-4">Service Provider</h3>
            <p className="whitespace-pre-line text-gray-600">{hospital_name}</p>
            <p className="whitespace-pre-line text-xs text-gray-600">{address.street}</p>
            <p className="whitespace-pre-line text-xs text-gray-600">{address.city}</p>
            <p className="whitespace-pre-line text-xs text-gray-600">{hospital_contact.email}</p>
            <p className="whitespace-pre-line text-xs text-gray-600">{hospital_contact.phone}</p>
        </div>
    )
}


export const Supplier = ({ name }: { name: string }) => {
    return (
        <div>
            <h2 className="text-sm font-semibold text-gray-800 mb-2">From:</h2>
            <p className="whitespace-pre-line text-gray-600">{name}</p>
        </div>
    )
}


interface ToProps {
    id: number,
    name: string,
    address: string,
    phone: string,
    email: string,
}


export const To = ({ id, name, address, phone, email }: ToProps) => {
    return (
        <div className="bg-blue-50 p-6 rounded-lg">
            <h3 className="text-sm font-semibold text-blue-600 uppercase mb-4">Bill To</h3>
            <p className="whitespace-pre-line text-gray-600">{name} ({id})</p>
            <p className="whitespace-pre-line text-xs text-gray-600">{address}</p>
            <p className="text-gray-600 text-xs">{email}</p>
            <p className="text-gray-600 text-xs">{phone}</p>
        </div>
    )
}



interface TotalsProps {
    subtotal: number,
    discount: number,
    discount_amount?: number,
    tax_amount?: number,
    tax: number,
    total: number,
}



export const Totals = ({ subtotal, discount, discount_amount, tax, tax_amount, total }: TotalsProps) => {
    return (
        <div className="ml-auto w-[300px]">
            <div className="space-y-2">
                <div className="flex justify-between">
                    <span className="text-gray-600">Subtotal:</span>
                    <span className="text-gray-900 font-mono">{currencyFormat(subtotal)}</span>
                </div>
                <div className="flex justify-between">
                    <span className="text-gray-600">Tax ({tax?.toFixed(2)}%):</span>
                    <span className="text-gray-900 font-mono">{currencyFormat(tax_amount || (tax / 100) * subtotal)}</span>
                </div>
                <div className="flex justify-between">
                    <span className="text-gray-600">Discount ({discount?.toFixed(2)}%):</span>
                    <span className="text-gray-900 font-mono">{currencyFormat(discount_amount || (discount / 100) * subtotal)}</span>
                </div>
                <div className="flex justify-between border-t pt-2">
                    <span className="font-bold text-lg text-gray-800">Grand Total:</span>
                    <span className="font-bold text-lg text-gray-800 font-mono">{currencyFormat(total)}</span>
                </div>
            </div>
        </div>
    )
}




interface footerProps {
    paymentInfo: string,
    notes?: string,
}

export const PdfFooter = ({ paymentInfo, notes }: footerProps) => {
    return (
        <div className="grid grid-cols-2 gap-8">
            <div>
                <h3 className="text-sm font-semibold text-gray-800 mb-2">Payment Information</h3>
                <p className="whitespace-pre-line text-muted-foreground text-sm">{paymentInfo}</p>
            </div>
            <div>
                <h3 className="text-sm font-semibold text-gray-800 mb-2">Notes</h3>
                <p className="whitespace-pre-line text-muted-foreground text-sm">{`Thanks for your business. \n ${notes}`}</p>
            </div>
        </div>
    )
}

interface PdfActionsProps extends ButtonHTMLAttributes<HTMLButtonElement> { }


export const PdfActions = React.forwardRef<HTMLButtonElement, PdfActionsProps>(({ ...props }, ref) => {
    return (
        < div className="fixed bottom-4 right-4" >
            <div className="flex gap-2">
                <button
                    className="flex items-center justify-center gap-2 rounded-lg hover:bg-red-500 border-2 border-red-500 px-4 py-2 text-sm font-medium text-red-600 hover:text-white"
                    onClick={() => window.history.back()}>
                    Back
                </button>
                <button
                    className="flex items-center justify-center gap-2 rounded-lg hover:bg-blue-500 border-2 border-blue-500 px-4 py-2 text-sm font-medium text-blue-600 hover:text-white"
                    ref={ref}
                    {...props}
                >
                    <Printer /> Print
                </button>
            </div>
        </div >
    )
})