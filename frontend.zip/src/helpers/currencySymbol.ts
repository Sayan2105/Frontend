export const currencySymbol = () => { // can be add more 
    return '₹'
}