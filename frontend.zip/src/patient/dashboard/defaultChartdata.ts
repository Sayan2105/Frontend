export const chartData = [
  { month: "January", Expense: 186 },
  { month: "February", Expense: 305 },
  { month: "March", Expense: 237 },
  { month: "April", Expense: 73 },
  { month: "May", Expense: 209 },
  { month: "June", Expense: 214 },
]