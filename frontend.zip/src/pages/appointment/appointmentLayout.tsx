import { Outlet } from 'react-router-dom'

const AppointmentLayout = () => {
    return (
        <Outlet></Outlet>
    )
}

export default AppointmentLayout