import { Outlet } from 'react-router-dom'

const StaffProfileLayout = () => {
    return (
        <Outlet></Outlet>
    )
}

export default StaffProfileLayout