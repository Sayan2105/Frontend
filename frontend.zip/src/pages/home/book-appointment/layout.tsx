import { Outlet } from "react-router-dom"

const HomepageAppointmentLayout = () => {
    return (
        <Outlet />
    )
}

export default HomepageAppointmentLayout