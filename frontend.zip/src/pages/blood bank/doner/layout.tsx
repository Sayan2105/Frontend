import { Outlet } from "react-router-dom"

const DonorLayouts = () => {
  return (
    <Outlet></Outlet>
  )
}

export default DonorLayouts