import { Outlet } from 'react-router-dom'

const BloodComponentsLayout = () => {
    return (
        <Outlet></Outlet>
    )
}

export default BloodComponentsLayout